---
layout: default
title: Report
permalink: /report/
---

<ul class="posts">

    {% for post in site.categories.report reverse %}
    <div class="post-recorder"> 
        <span class="post-date-title">
            <span id="post-date">{{ post.date | date: "%m-%d-%Y"}}</span>
            <span id="post-title">{{ post.title }}</span>
        </span>
        <div class="post-content">{{ post.content }}</div>
    </div>
    {% endfor %}

</ul>


