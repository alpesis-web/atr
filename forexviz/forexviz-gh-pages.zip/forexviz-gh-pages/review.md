---
layout: default
title: Review
permalink: /review/
---

<ul class="posts">

    {% for post in site.categories.review reverse %}
    <div class="post-recorder"> 
        <span class="post-date-title">
            <span id="post-date">{{ post.date | date: "%m-%d-%Y"}}</span>
            <span id="post-title">{{ post.title }}</span>
        </span>
        <div class="post-content">{{ post.content }}</div>
    </div>
    {% endfor %}

</ul>



