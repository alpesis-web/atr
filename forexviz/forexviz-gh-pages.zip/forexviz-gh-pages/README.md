ForexViz
========

ForexViz is built by Ruby Jekyll.


## Release Notes


| Version | Date     | Description                                     |
|:--------|:---------|:------------------------------------------------|
| V2.0.1  | 20140805 | New version released with one-page              |


