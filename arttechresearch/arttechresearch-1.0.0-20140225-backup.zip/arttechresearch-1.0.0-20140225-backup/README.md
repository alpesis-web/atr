ArTechResearch
=======

- syntax hightligh
- date format
- CSS
- post: links to previous/next
- post: linked to post list
