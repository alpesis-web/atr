#######################################
Todo
#######################################

pages:

- devkits: adding full list of the devkits
- projects: adding full list of the projects
- reading: adding pocket api
- presentations: adding slideshare api
