##################################
Table of Content
##################################

Reference:

http://localhost:4000/tech/2015/10/17/generating-toc-with-javascript-for-octopress/
