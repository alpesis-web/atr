############################
Social
############################

- `perfections`_

.. _`perfections`: http://perfecticons.com


1. click the link above

2. design the icons

3. download the fonts, and then save to /octopress/source/assets/fonts/*

4. add scss file to /octopress/sass/partials/_social.scss

5. add html file to /octopress/source/_includes/social.html

6. update the links in /octopress/_config.yml
