###############################
Tag Generator
###############################

- octopress/plugin/tag_generator.rb
- octopress/source/_layout/tag_index.html
- octopress/_config.yml: **tag_dir**
