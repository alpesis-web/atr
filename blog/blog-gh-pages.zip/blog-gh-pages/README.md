Blogging with Jekyll
====

### Versions

| Version | Date     | Remark                                               |
|:--------|:---------|:-----------------------------------------------------|
| v2.3.0  | 20140801 | re-design UI                                         |
| v2.2.0  | 20140618 | developed new categories and main page               |
| v2.1.0  | 20140617 | ui re-design, css updated                            |
| v2.0.1  | 20140528 | post-navigation (button: previous/next) included     |
| v2.0.0  | 20140521 | rebuilt the blog with new structure and new design   |
| v1.0.0  | 20140225 | first version launched, blog built by jekyll         |


### File Structure

```
.
|--- _config.yml
|
|--- assets
|      |---- css
|      |---- js
|      |---- fonts
|
|--- _includes
|        |------- head.html      (setting)
|        |------- header.html            
|        |------- footer.html
|--- _layouts
|        |------- default.html   (head/header/footer)
|                    |--------- post.html  
|                    |--------- page.html
|                                   |------ art.md
|                                   |------ tech.md
|                                   |------ report.md
|                                   |------ piano.md
|                                   |------ language.md 
|--- _posts
|      |--- art
|      |--- tech
|      |--- report
|      |--- piano
|      |--- language
|
|
|--- index.html
       |--- art.md
       |--- tech.md
       |--- report.md
       |--- piano.md
       |--- language.md
```

