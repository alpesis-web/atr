---
layout: page
title: Posts 
permalink: /posts/
---

<div class="home">

  <ul class="posts">

    {% for post in site.posts reverse %}

        <li class="post-lists">
            <span class="post-date">{{ post.date | date: "%B %d, %Y"}}</span>
            <a class="post-link" href="{{ post.url | prepend: site.baseurl }}">{{ post.title }}</a> 
        </li>

    {% endfor %}

  </ul>

</div>

