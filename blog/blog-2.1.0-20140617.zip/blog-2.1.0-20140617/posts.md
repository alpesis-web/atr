---
layout: page
title: Posts 
permalink: /posts/
---

<div class="home">

  <ul class="posts">

    {% for post in site.posts reverse %}

        {% capture y %} {{ post.date | date: "%Y" }}
        {% endcapture %}
        {% if year != y %}
            {% assign year = y %}
            <li>{{ y }}</li>
        {% endif %}

        <li>
            <span class="post-date">{{ post.date | date: "%b %-d, %Y"}}</span>
            <a class="post-link" href="{{ post.url | prepend: site.baseurl }}">{{ post.title }}</a>
        </li>

    {% endfor %}

  </ul>

</div>


