Blogging with Jekyll
====

### Versions

| Version | Date     | Remark                                               |
|:--------|:---------|:-----------------------------------------------------|
| v2.0.1  | 20140528 | post-navigation (button: previous/next) included     |
| v2.0.0  | 20140521 | rebuilt the blog with new structure and new design   |
| v1.0.0  | 20140225 | first version launched, blog built by jekyll         |
