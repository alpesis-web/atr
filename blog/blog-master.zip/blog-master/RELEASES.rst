#############################
Release Notes
#############################


------------------------
v3 - Oct 4 2015
------------------------

v3.0.0 - 20151004

- rebuilt the blog with octopress

------------------------
v2 - May 21 2014
------------------------


v2.3.0 - 20140801

- re-design UI

v2.2.0 - 20140618

- developed new categories and main page

v2.1.0 - 20140617

- ui re-design, css updated

v2.0.1 - 20140528

- post-navigation (button: previous/next) included


v2.0.0 - 20140521

- rebuilt the blog with new structure and new design

------------------------
v1 - Feb 25 2014
------------------------

v1.0.0 - 20140225

- first version launched, blog built by jekyll

