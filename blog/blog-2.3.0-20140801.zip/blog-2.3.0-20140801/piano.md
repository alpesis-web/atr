---
layout: page
title: Piano
permalink: /piano/
---

<div class="post-list">

    {% for post in site.categories.piano reverse %}
        
        <li class="post-recorder">
            <span id="post-date">{{ post.date | date: "%m-%d-%Y"}}</span>
            <a id="post-link" href="{{ site.baseurl }}{{post.url}}">{{ post.title }}</a>
        </li>

    {% endfor %}

</div>


