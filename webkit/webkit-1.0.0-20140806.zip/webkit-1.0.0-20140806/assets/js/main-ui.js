// post-content-list with fold effect

$(document).ready(function(){
    // Don't display the article
    $(".post-content").css("display", "none");
    // Actions on post-title
    $(".post-title-bar").click(function(){
        $(".post-content").css("display", "none"); // don't display the article
        $(".post-recorder").css("background-color", "#E6E6B8"); // highlight the post-title
        $(this).next(".post-content").slideToggle("slow");
    });
});
