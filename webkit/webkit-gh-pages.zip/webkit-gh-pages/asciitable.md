---
layout: default
title: ASCII Table
permalink: /asciitable/
---

<ul class="posts">

    {% for post in site.categories.ascii reverse %}
    <div class="post-recorder"> 
        <span class="post-title-bar">
            <span id="post-title-icon"></span>
            <span id="post-title">{{ post.title }}</span>
        </span>
        <div class="post-content">{{ post.content }}</div>
    </div>
    {% endfor %}

</ul>
